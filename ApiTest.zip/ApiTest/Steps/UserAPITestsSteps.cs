﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ApiServices.Entities;
using ApiTest.DataTypes;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace ApiTest.Steps
{
    [Binding]
    public class UserApiTestsSteps
    {
        private CreateUserDataType _createUser;
        private IRestResponse _response;
        private GetUserResponseModel _getUserdetails;
        private readonly IUserServices _userServices = new UserServices();
        private const string url = "api/users";


        [When(@"I request create a user with details:")]
        public async Task WhenIRequestCreateAUserWithDetails(Table table)
        {
            _createUser = table.CreateInstance<CreateUserDataType>();
            var body = BuildRequestBody();
            _response = await _userServices.PostRequestAsync(url, body);

        }


        [When(@"I request Get a user resource by valid (.*)")]
        public async Task WhenIRequestGetAUserResourceByValid(int userid)
        {
            var urlExtension = url + "/" + userid;
            _response = await _userServices.GetRequestAsync(urlExtension);
            if (_response.IsSuccessful)
            {
                _getUserdetails = JsonConvert.DeserializeObject<GetUserResponseModel>(_response.Content);
            }
        }

        [When(@"I request Get users")]
        public async Task WhenIRequestGetUsers()
        {
            _response = await _userServices.GetRequestAsync(url);
        }


        [When(@"I update the user details:")]
        public async Task WhenIUpdateTheUserDetails(Table table)
        {
            _createUser = table.CreateInstance<CreateUserDataType>();
            var urlExtension = url + "/" + _getUserdetails.Data.Id;
            var body = BuildRequestBody();
            _response = await _userServices.PutRequestAsync(urlExtension,body);
        }

        [Then(@"I receive a response as (.*)")]
        public void ThenIReceiveAResponse(string status)
        {
            Assert.AreEqual(actual:status,expected:_response.StatusCode.ToString());
        }
        
        [Then(@"I validate the created user response body")]
        public void ThenIValidateTheUserResponseBody()
        {
            var responseBody = JsonConvert.DeserializeObject<CreateUserResponseModel>(_response.Content);
            var requestRequestedTime = _response.Headers
                .Where(x => x.Name != null && x.Name.Equals("Date"))
                .Select(x => x.Value).FirstOrDefault()?.ToString();
            var createdOnDateTime = DateTimeOffset.Parse(requestRequestedTime).ToString("s");
            Assert.AreEqual(_createUser.Name, responseBody.Name);
            Assert.AreEqual(_createUser.Job, responseBody.Job);
            Assert.AreEqual(createdOnDateTime, responseBody.CreatedAt.ToString("s"));

        }

        [Then(@"I validate the updated user response body")]
        public void ThenIValidateTheUpdatedUserResponseBody()
        {
            var responseBody = JsonConvert.DeserializeObject<UpdateUserResponseModel>(_response.Content);
            var requestRequestedTime = _response.Headers
                .Where(x => x.Name != null && x.Name.Equals("Date"))
                .Select(x => x.Value).FirstOrDefault()?.ToString();
            var createdOnDateTime = DateTimeOffset.Parse(requestRequestedTime).ToString("s");
            Assert.AreEqual(_createUser.Name, responseBody.Name);
            Assert.AreEqual(_createUser.Job, responseBody.Job);
            Assert.AreEqual(createdOnDateTime, responseBody.UpdatedAt.ToString("s"));
        }


        [Then(@"the response body is not empty")]
        public void ThenTheResponseBodyIsNotEmpty()
        {
            Assert.That(_response.Content, Is.Not.Null);
        }

        [Then(@"I validate the list of users response body")]
        public void ThenIValidateTheListOfUsersResponseBody()
        {
            var responseBody = JsonConvert.DeserializeObject<GetListOfUsersResponseModel>(_response.Content);
            Assert.IsNotEmpty(responseBody.Data);
            Assert.True(responseBody.Page>0);
            Assert.True(responseBody.TotalPages>0);
            Assert.True(responseBody.PerPage > 0);
            Assert.True(responseBody.Total > 0);
            Assert.IsNotEmpty(responseBody.Support.Text);
            Assert.IsNotEmpty(responseBody.Support.Url.ToString());

        }

        private string BuildRequestBody()
        {
            var createUserRequestBody = new CreateUserRequestModel()
            {
                Name = _createUser.Name,
                Job = _createUser.Job
            };
            var body = JsonConvert.SerializeObject(createUserRequestBody);
            return body;
        }
    }
}
