﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiTest.DataTypes
{
    public class CreateUserDataType
    {
        public string Name { get; set; }

        public string Job { get; set; }
    }
}

