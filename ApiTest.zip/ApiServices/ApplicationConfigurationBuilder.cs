﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;


namespace ApiServices
{
    public class ApplicationConfigurationBuilder
    {
        public static Configuration _configuration;
        public static Configuration Instance => _configuration ?? BuildConfiguration();

        private static Configuration BuildConfiguration()
        {
            var dir = Directory.GetCurrentDirectory();
            var config =
                new ConfigurationBuilder()
                    .SetBasePath(dir)
                    .AddJsonFile("appsettings.json", true)
                    .AddEnvironmentVariables()
                    .Build();
            return _configuration = config.GetSection("testSettings").Get<Configuration>();

        }
    }
    public class ApplicationSetting
    {
        public Uri BaseUri { get; set; }
    }

    public class Configuration
    {
        public ApplicationSetting AppSettings { get; set; }
    }
}
