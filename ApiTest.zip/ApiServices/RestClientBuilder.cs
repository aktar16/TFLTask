﻿using System;
using System.Threading.Tasks;
using RestSharp;

namespace ApiServices
{
    public class RestClientBuilder
    
    {
        private RestClient _client;
        private RestRequest _request;
        private string _content;

        public RestClientBuilder UsingBaseUri(Uri uri = null)
        {
            _client = new RestClient(uri ?? ApplicationConfigurationBuilder.Instance.AppSettings.BaseUri);
            
            return this;
        }

        public RestClientBuilder ForResource(string urlExtension, Method httpVerb)
        {
            _request = new RestRequest(urlExtension, httpVerb);
            return this;
        }

        public RestClientBuilder WithJsonContent(string content)
        {
            _content = content;
            _request.AddParameter("application/json", _content, ParameterType.RequestBody);
            return this;

        }
        public async Task<IRestResponse> ExecuteRequestAsync()
        {

            return await _client?.ExecuteAsync(_request ?? throw new InvalidOperationException());
        }
    }

}
