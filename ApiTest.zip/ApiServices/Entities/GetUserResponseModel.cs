﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace ApiServices.Entities
{
  public class GetUserResponseModel
    {
        [JsonProperty("data")]
        public UsersData Data { get; set; }

        [JsonProperty("support")]
        public Support Support { get; set; }
    }
}
