﻿using Newtonsoft.Json;

namespace ApiServices.Entities
{
   public class CreateUserRequestModel
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("job")]
        public string Job { get; set; }
    }
}

