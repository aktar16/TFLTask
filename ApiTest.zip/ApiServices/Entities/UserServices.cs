﻿using System.Threading.Tasks;
using RestSharp;

namespace ApiServices.Entities
{
    public interface IUserServices
    {
        Task<IRestResponse> GetRequestAsync(string urlExtension);
        Task<IRestResponse> PostRequestAsync(string urlExtension, string jsonBody);
        Task<IRestResponse> PutRequestAsync(string urlExtension, string jsonBody);
        Task<IRestResponse> DeleteRequestAsync(string urlExtension);
    }

    public class UserServices:IUserServices
    {
    public async Task<IRestResponse> GetRequestAsync(string urlExtension)
    {
        return await new RestClientBuilder()
            .UsingBaseUri()
            .ForResource(urlExtension, Method.GET)
            .ExecuteRequestAsync();
    }

    public async Task<IRestResponse> PostRequestAsync(string urlExtension, string jsonBody)
    {
        return await new RestClientBuilder()
            .UsingBaseUri()
            .ForResource(urlExtension, Method.POST)
            .WithJsonContent(jsonBody)
            .ExecuteRequestAsync();
    }


    public async Task<IRestResponse> PutRequestAsync(string urlExtension, string jsonBody)
    {
        return await new RestClientBuilder()
            .UsingBaseUri()
            .ForResource(urlExtension, Method.PUT)
            .WithJsonContent(jsonBody)
            .ExecuteRequestAsync();
    }
    public async Task<IRestResponse> DeleteRequestAsync(string urlExtension)
    {
        return await new RestClientBuilder()
            .UsingBaseUri()
            .ForResource(urlExtension, Method.DELETE)
            .ExecuteRequestAsync();
    }

    }
}
