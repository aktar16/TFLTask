﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace ApiServices.Entities
{
     public class UpdateUserResponseModel
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("job")]
        public string Job { get; set; }

        [JsonProperty("updatedAt")]
        public DateTimeOffset UpdatedAt { get; set; }
    }
}
